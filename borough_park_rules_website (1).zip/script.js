const sidebar=document.getElementById('sidebar');
document.getElementById('mobileMenu')?.addEventListener('click',()=>sidebar.classList.toggle('open'));
document.querySelectorAll('.nav-link').forEach(link=>link.addEventListener('click',()=>{
  document.querySelectorAll('.nav-link').forEach(item=>item.classList.remove('active'));
  link.classList.add('active'); sidebar.classList.remove('open');
}));
const searchInputs=[document.getElementById('mobileSearch')].filter(Boolean);
searchInputs.forEach(input=>input.addEventListener('input',()=>{
  const term=input.value.trim().toLowerCase();
  document.querySelectorAll('.nav-link').forEach(link=>{
    link.style.display=link.textContent.toLowerCase().includes(term)?'flex':'none';
  });
  document.querySelectorAll('.side-label').forEach(label=>label.style.display=term?'none':'block');
}));
